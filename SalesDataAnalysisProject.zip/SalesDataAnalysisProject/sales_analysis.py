import csv
from collections import defaultdict
import os
import sys

def load_sales_data(filename):
    """Load sales data from a CSV file."""
    if not os.path.exists(filename):
        raise FileNotFoundError(f"Error: File '{filename}' not found.")

    sales_data = []
    try:
        with open(filename, mode='r') as file:
            csv_reader = csv.DictReader(file)
            for row in csv_reader:
                sales_data.append({
                    'product': row['Product'],
                    'category': row['Category'],
                    'quantity': int(row['Quantity']),
                    'price': float(row['Price'])
                })
    except KeyError as e:
        raise ValueError(f"Error: Missing column in CSV - {e}")
    except ValueError as e:
        raise ValueError(f"Error: Incorrect data formatting - {e}. Ensure 'Quantity' and 'Price' are numeric values.")
    
    return sales_data

def calculate_average_price(data):
    """Calculate average price per category."""
    category_totals = defaultdict(lambda: [0, 0])  # total price, count
    for entry in data:
        category_totals[entry['category']][0] += entry['price']
        category_totals[entry['category']][1] += 1
    
    average_prices = {category: total / count for category, (total, count) in category_totals.items()}
    return average_prices

def product_with_highest_quantity(data):
    """Identify the product with the highest quantity sold."""
    max_quantity_product = max(data, key=lambda x: x['quantity'])
    return max_quantity_product['product'], max_quantity_product['quantity']

def save_analysis_report(average_prices, highest_quantity_product, output_file):
    """Save the analysis report to a CSV file."""
    try:
        with open(output_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Category", "Average Price"])
            for category, avg_price in average_prices.items():
                writer.writerow([category, f"${avg_price:.2f}"])

            writer.writerow([])  
            writer.writerow(["Product with Highest Quantity Sold", "Quantity"])
            writer.writerow([highest_quantity_product[0], highest_quantity_product[1]])
    except IOError as e:
        raise IOError(f"Error: Could not write to file '{output_file}'. {e}")
    else:
        print(f"\nAnalysis report successfully saved to '{output_file}'.")

def main():
    if len(sys.argv) < 2:
        print("Usage: python sales_analysis.py <sales_data.csv>")
        sys.exit(1)

    filename = sys.argv[1]
    output_file = 'sales_analysis_report.csv'  

    try:
        sales_data = load_sales_data(filename)

        average_prices = calculate_average_price(sales_data)
        print("\n--- Average Price by Category ---")
        for category, avg_price in average_prices.items():
            print(f"{category}: ${avg_price:.2f}")

        highest_quantity_product = product_with_highest_quantity(sales_data)
        print(f"\nProduct with Highest Quantity Sold: {highest_quantity_product[0]} with a quantity of {highest_quantity_product[1]}")

        save_analysis_report(average_prices, highest_quantity_product, output_file)

    except (FileNotFoundError, ValueError, IOError) as e:
        print(f"\nError: {e}")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

if __name__ == '__main__':
    main()
