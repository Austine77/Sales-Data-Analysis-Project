# Sales Analysis Project

This project contains a Python script (`sales_analysis.py`) that analyzes sales data from a CSV file.

## How to Run the Script:
1. Open a terminal in VS Code.
2. Ensure the sales_data.csv file is in the same folder as the script.
3. Run the following command:


## Output:
- The script will display the average price by category and the product with the highest quantity sold.
- An analysis report will also be saved to a CSV file called `sales_analysis_report.csv`.

## Requirements:
- Python 3.x
